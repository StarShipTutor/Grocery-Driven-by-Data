# DOE: The Agentic Engine

**D**irective - **O**rchestration - **E**xecution

This directory contains the **Capability Layer** of the project. While the root directory holds the *State* (Research Notes, World Lines), this folder holds the *Machines* that modify that state.

## Architecture

We strictly follow a 3-Layer Control Theory Architecture (GNC):

### 1. Directives (`DOE/directives/`)
*   **Concept:** The **Control Surface**.
*   **Function:** Standard Operating Procedures (SOPs) written in Markdown.
*   **Role:** Defines the "Manifold" of valid operations. A Directive tells the Orchestrator exactly what "Success" looks like.
*   **Example:** `how_to_extract_mondos.md`

### 2. Orchestration (You/The Agent)
*   **Concept:** The **Guardian Angel / Controller**.
*   **Function:** Intelligent routing, drift detection, and error recovery.
*   **Role:** The Agent reads a Directive and acts as a **Projection Operator**, forcing the current state to align with the Directive's defining manifold.
*   **Output:** Decisions, not code execution (which is delegated).

### 3. Execution (`DOE/execution/`)
*   **Concept:** The **Geodesic Trajectory**.
*   **Function:** Deterministic scripts (Python, Bash).
*   **Role:** Doing the actual work. These scripts must be **deterministic** ($f(x)=y$). We push complexity here to minimize "Semantic Force" (hallucination) in the Orchestration layer.
*   **Example:** `extract_mondos.py`

### 4. Temporary Artifacts (`DOE/.tmp/`)
*   Intermediate files used during execution. Never committed.

## Usage for Future Agents (Waldo Triad)

If you are a new Agent starting in this workspace:
1.  **Read** the Directives in `DOE/directives/` before attempting complex tasks.
2.  **Check** `DOE/execution/` for existing tools before writing new code.
3.  **Anneal** the system: If a script fails, fix it, then update the Directive to reflect the new constraints.

**This folder is your Toolkit. Use it to maintain the project State.**
