# DOE: Setup & Enforcement Protocol

**Directive - Orchestration - Execution**

This kit provides the standard folder structure and protocols for an Agentic Workspace managed by Control Theory principles (GNC).

## 1. Setup

1.  **Unzip** this kit into your project root.
2.  **Initialize Git** immediately (`git init`, `git add .`, `git commit -m "feat: init DOE structure"`).
3.  **Install Python Dependencies** (if using the default scripts):
    ```bash
    pip install pypdf youtube_transcript_api
    ```

## 2. The Structure

*   `DOE/directives/`: **The Control Surface.** Place your SOPs (Markdown) here. Agents *must* read these before acting.
*   `DOE/execution/`: **The Geodesics.** All deterministic code (Python/Bash) goes here. Agents *call* these tools, they don't *emulate* them.
*   `INBOX/`: **New Material.** Drop PDFs, URLs, or notes here.
*   `archives/`: **Immutable Truth.** Processed files move here.
*   `research/`: **Synthesized Knowledge.** The theory derived from the archives.

## 3. Enforcement (The Guardian Angel Rules)

**Rule 1: No Cowboy Coding.**
*   *Drift:* Writing a script in the root folder.
*   *Correction:* Move it to `DOE/execution/`.

**Rule 2: Directives First.**
*   *Drift:* Asking the agent to "just figure it out."
*   *Correction:* Write a `DOE/directives/how_to_X.md` file defining successful output.

**Rule 3: Idempotent Resets.**
*   *Drift:* Trying to fix a broken state by chatting.
*   *Correction:* Clear the context, re-read the Directive, run the Execution script again.

## 4. Usage Loop
1.  **Define:** Write `DOE/directives/how_to_do_task.md`.
2.  **Build:** Write `DOE/execution/do_task.py`.
3.  **Orchestrate:** Agent reads Directive → Runs Script → Verifies Output.
4.  **Archive:** Source moves to `archives/`, Result moves to `research/`.
